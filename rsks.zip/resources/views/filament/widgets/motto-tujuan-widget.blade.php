<x-filament-widgets::widget>
    <x-filament::section style="background-color:blanchedalmond">
        <div class="flex items-center gap-x-12">
            <p class="text-sm text-gray-600">
                <ol class="list-decimal pl-5 text-gray-600" style="padding-left: 1rem;">
                    <li><b>Motto:</b> Kesehatan Anda, prioritas kami.</li>
                    <li><b>Tujuan:</b> Menjadi rumah sakit rujukan kesehatan dalam pelayanan kanker, jantung, stroke dan uronefrologi dengan pelayanan yang terbaik serta meningkatkan kualitas hidup masyarakat.</li>
                </ol>
            </p>
        </div>
    </x-filament::section>
</x-filament-widgets::widget>
